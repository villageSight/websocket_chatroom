<!-- # webscokt_room  @villageSight create 2017/3/15-->
使用方法，git clone https://github.com/villageSight/webscokt_room.git;
启动服务 node app 即可，就是这么简单，可以部署到自己的服务器上，就是一款简单的聊天软件了
